rd=[255 99 71]/255;                                                         % colors for aggressive & optimal phenotypes
opt=[1 0.70 0];

runs=40;

K = 500;                                                                % carrying capacity
betaAggr=0.125;                                                         % Birth rate in the aggressive mode
deltaAggr=0.075;                                                        % Death rate in the aggressive mode
betaDef=0.025;                                                          % Birth rate in the defensive mode
deltaDef=0.005;                                                         % Death rate in the defensive mode 

proportion=0.2;
timesteps=400;
cycles=7;

PopSZ=zeros(runs,timesteps*cycles,2);
defmode=zeros(timesteps*cycles,runs);                                       % record modes (defensive or aggressive) for Figure 3D

for j=1:runs                                                                % over runs
    n1Init=K*proportion;                                                    % total initial population size=2*80=160
    n2Init=K*proportion;
    
    for k=1:cycles                                                          % over cycles
        shft=(k-1)*timesteps;
        PopSZ(j,shft+1,1)=n1Init;
        PopSZ(j,shft+1,2)=n2Init;
        
        for t=2:timesteps                                                   % over timesteps within a cycle 
            n1=PopSZ(j,shft+t-1,1);
            n2=PopSZ(j,shft+t-1,2);
                        
            births1=poissrnd(n1*betaAggr);                                  % aggressive phenotype
            deaths1=poissrnd(n1*(deltaAggr+(betaAggr-deltaAggr)*(n1+n2)/K));

            if(CtrlCube(200+t,n2+1,n1+1)>0)                                 % optimal phenotype
                births2=poissrnd(n2*betaDef);
                deaths2=poissrnd(n2*(deltaDef+(betaDef-deltaDef)*(n1+n2)/K));
                defmode(400*(k-1)+t,j)=1;
            else
                births2=poissrnd(n2*betaAggr);
                deaths2=poissrnd(n2*(deltaAggr+(betaAggr-deltaAggr)*(n1+n2)/K));                        
            end;

            PopSZ(j,shft+t,1)=max(0,n1+births1-deaths1);                    % update population sizes
            PopSZ(j,shft+t,2)=max(0,n2+births2-deaths2);                                           
        end;
        
        if (PopSZ(j,shft+timesteps,1)+PopSZ(j,shft+timesteps,2))==0         % the whole metapopulation is dead
            n1Init=0;
            n2Init=0;
        else                                                                % not dead -> use their relative rations and the next cycle starts with the population size to 160.
            n1Init=round(160*PopSZ(j,shft+timesteps,1)/(PopSZ(j,shft+timesteps,1)+PopSZ(j,shft+timesteps,2)));
            n2Init=round(160*PopSZ(j,shft+timesteps,2)/(PopSZ(j,shft+timesteps,1)+PopSZ(j,shft+timesteps,2)));
        end;
    end;
end;

%% -- plot Figure 3C ---
for r=1:5                                                                % select representative run for figures 3C and 3D; only 5 first here
    figure(3);
    
    % plot backgrounds for cycles
    rectangle('Position',[401 0 400 750],'FaceColor',[0.92 0.92 0.92],'EdgeColor',[0.92 0.92 0.92]); hold on;
    rectangle('Position',[1201 0 400 750],'FaceColor',[0.92 0.92 0.92],'EdgeColor',[0.92 0.92 0.92]); 
    rectangle('Position',[2001 0 400 750],'FaceColor',[0.92 0.92 0.92],'EdgeColor',[0.92 0.92 0.92]); 

    % plot curves & lines
    plot(PopSZ(r,:,1)+PopSZ(r,:,2),'-','color','k','linewidth',2);
    plot(PopSZ(r,:,2),'color',opt,'linewidth',6); 
    plot(PopSZ(r,:,1),'-','color',rd,'linewidth',6);
    plot(PopSZ(r,:,1)+PopSZ(r,:,2),'-','color','k','linewidth',2);
    plot([0 7*400],[500 500],'--','linewidth',1.5,'color',[0 0 0]);

    set(gca,'fontsize',25,'linewidth',2);
    ylabel('Population size', 'fontsize',35);
    xlabel('Time', 'fontsize',35);
    legend('Total','Anticipative','Aggressive');
    box on;
    ylim([0 750]);
    xlim([0 2800]);

    % change drawing order -> axes on top
    ax=gca;
    set( ax, 'Layer', 'top' );

    hold off;
    title('panel C','fontsize',25);
    fprintf('run #%d/40 (press any key to continue)\n',r);

    plotFigure4D;
    pause();
    figure(3); 
    if r~=5
        clf;
    end;
end;

