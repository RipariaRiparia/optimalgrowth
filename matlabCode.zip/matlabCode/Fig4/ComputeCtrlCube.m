% a main function for computing CtrlCube slice-wise

K=500;
range=1.75;
tmax=600;

CtrlCube=zeros(tmax,range*K+1,range*K+1);
for i=0:(range*K)
    fprintf('%d ',i);
    CtrlCube(:,:,i+1)=optimalGrowthSlice(i);
end;
fprintf('\n');
