figure(5);

imagesc(PopSZ(:,:,2)); colormap([linspace(1,1,20)' linspace(1,0.5,20)' linspace(1,0,20)']);
caxis([0 700]);
set(gca,'fontsize',30,'ytick',[],'linewidth',2);
ylabel('Simulations','fontsize',35);
xlabel('Time','fontsize',35);
axis square;
title('panel E','fontsize',25);