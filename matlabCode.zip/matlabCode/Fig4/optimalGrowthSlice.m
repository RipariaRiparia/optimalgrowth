% compute a control map slice (fixed competitors population size)

function Chjb=optimalGrowthSlice(competitorSZ)
    K = 500;                                                                % effective carrying capacity                                                   
    range=1.75;
    
    betaAggr=0.125;                                                         % Birth rate in the aggressive mode
    deltaAggr=0.075;                                                        % Death rate in the aggressive mode
    betaDef=0.025;                                                          % Birth rate in the defensive mode
    deltaDef=0.005;                                                         % Death rate in the defensive mode    
        
    Wnn1=zeros(length(0:(K*range)),length(-40:(K*range)));                  % defensive                
    Wnn2=zeros(length(0:(K*range)),length(-40:(K*range)));                  % aggressive

    parfor nInit=0:(K*range)                                                % transition matrices
        Wnn1(1+nInit,:)=computeSkellamVector(-40-nInit,(K*range)-nInit,nInit*betaDef,nInit*(deltaDef+(betaDef-deltaDef)*(nInit+competitorSZ)/K));
        Wnn2(1+nInit,:)=computeSkellamVector(-40-nInit,(K*range)-nInit,nInit*betaAggr,nInit*(deltaAggr+(betaAggr-deltaAggr)*(nInit+competitorSZ)/K));
    end;

    neqORzero=41;

    % normalization
    tmp=[sum(Wnn1(:,1:neqORzero),2) Wnn1(:,neqORzero+1:end)];
    Wnn1bc=tmp./repmat(sum(tmp,2),1,(K*range)+1);

    tmp=[sum(Wnn2(:,1:neqORzero),2) Wnn2(:,neqORzero+1:end)]; 
    Wnn2bc=tmp./repmat(sum(tmp,2),1,(K*range)+1);

    tmax = 600;
    Jhjb=zeros(tmax+1,range*K+1);
    Chjb=zeros(tmax,range*K+1);
    Jhjb(tmax+1,:)=0:(range*K);
    v1=zeros(range*K+1,1);
    v2=zeros(range*K+1,1);

    % backward propagation (HJB)
    for ti=(tmax+1):-1:2
        J=Jhjb(ti,:);

        for xi=1:(range*K+1)
                v1(xi)=J(:)'*Wnn1bc(xi,:)'; 
                v2(xi)=J(:)'*Wnn2bc(xi,:)';
        end;   
    
        cmax = max(v1,v2);
        diff=v1-v2;
    
        Jhjb(ti-1,:)=cmax;
        Chjb(ti-1,:)=diff;
    end;
end
