% plots slices -- joined and finalized in PowerPoint

figure(1); 
imagesc(reshape(-CtrlCube(:,:,250),600,876)'); hold on;                    % set here the slice you want -- now the population size of a competitor is 200
set(gca,'ydir','normal','linewidth',2,'xtick',[],'ytick',[100 200 300 400 500],'yticklabel',[]); 
caxis([-1 1]); 
ylim([2 500]); 
xlim([201 600])
setTomatoskyColormap;
set(gca,'ydir','normal'); 
caxis([-1 1]); ylim([2 525]);
%plot([1 1001],[499 499],'--','linewidth',2,'color',[0.4 0.4 0.4]);          % remove these if not the topmost slice
%plot([1 1001],[299 299],'-','linewidth',2,'color',[0.4 0.4 0.4]); 
hold off;
title('a slice in panel A','fontsize',25);