fprintf('Computing a control cube ... (this can take several hours and needs a lot of space)\n');
fprintf('  The counter goes to 875: \n');
ComputeCtrlCube;
save('NewCube','CtrlCube','-V7.3');                                         % use load('NewCube') after the first time; file size = 2.93GB

%% --- plots ---
fprintf('  Computing panel A ...\n');
plotFigure4A;
pause(0.1);

CtrlCube=(CtrlCube>=0);                                                     % a binary representation is enough for the latter panels

fprintf('  Computing panel B ...\n');
plotFigure4B;
pause(0.1);

fprintf('  Computing panels C and D ...\n');
plotFigure4C;                                                               % launches plotFigure4D
pause(0.1);

fprintf('  Computing panel E ...\n');
plotFigure4E;


