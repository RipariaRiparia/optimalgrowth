rd=[255 99 71]/255;

figure(4);
for i=1:2000                                                                % plot background colors showing the modes
    if(defmode(i,r)==1)
        rectangle('Position',[i-0.5 1 1 K+98],'facecolor',[0.7706 0.8868 1.0000],'edgecolor','none'); hold on;
    else
        rectangle('Position',[i-0.5 1 1 K+98],'facecolor',[1.0000 0.8409 0.8124],'edgecolor','none'); hold on;
    end;
end;
plot(400+(2:399),PopSZ(r,400+(2:399),2),'color',[1 0.7 0],'linewidth',5);   % plot curves
plot(400+(2:399),PopSZ(r,400+(2:399),1),'color',rd,'linewidth',5);
plot(400+(2:399),PopSZ(r,400+(2:399),1),'k','linewidth',6);
plot(400+(2:399),PopSZ(r,400+(2:399),1),'color',rd,'linewidth',5);
plot(400+(2:399),PopSZ(r,400+(2:399),2),'k','linewidth',6);
plot(400+(2:399),PopSZ(r,400+(2:399),2),'color',[1 0.7 0],'linewidth',5);

plot([400 400+timesteps],[K K],'--','linewidth',3,'color',[0.4 0.4 0.4]);   % plot carrying capacity
set(gca,'linewidth',2,'fontsize',35);
xlabel('Time');
ylabel('Population size');
box on;
legend('Anticipative','Aggressive');
title('panel D','fontsize',25);

set(gca,'Layer','top');
ylim([0 K+100]);
xlim([400 400+timesteps]);
hold off;