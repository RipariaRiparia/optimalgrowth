figure(2);
imagesc(reshape(-(2*(CtrlCube(end,:,:)>0)-1),876,876));

set(gca,'ydir','normal','linewidth',3,'fontsize',25); 
caxis([-1 1]); 
xlim([2 525]); 
ylim([2 525]); 
ylabel('Population size of greedy phenotype');
xlabel('Population size of competing phenotype');
axis square;
title('panel B','fontsize',25);
setTomatoskyColormap;