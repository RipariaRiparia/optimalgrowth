figure(2);
plot(lags(1:111),[100:10:1200],'o','color','black','linewidth',1.5,'markersize',4,'markerfacecolor','w'); hold on;
ylabel('Cycle length')
xlabel('Median lag time')
set(gca,'fontsize',20,'linewidth',2)
ylim([100 1200]);
xlim([0 58]);
hold off;
