fprintf('  Computing a Skellam transition matrix and a control map ...\n');

cd ../Fig1;
[Cdiff,Wnn1bc,Wnn2bc]=computeControlMap(750);
tmax=750; PropagateProbabilities;
cd ../Fig3;

fprintf('  Computing panel AB ...\n');
plotFigure3AB;
pause(0.5);

computeLagCurve;
fprintf('  Computing panel C ...\n');
PlotFigure3C;


