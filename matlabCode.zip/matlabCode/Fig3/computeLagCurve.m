range=1.75;
intervals=[100:10:1200]; % cycle lengths
lags=zeros(1,length(intervals)); % space for optimal lag times

fprintf('\nComputing lag times for cycle lengths 100 - 1200:\n');
for idx=1:length(intervals)
    if mod(intervals(idx),100)==0
        fprintf('\n');
    end;    
    fprintf('%d ',intervals(idx));
    
    Cdiff=computeControlMapOnly(intervals(idx),K*range,Wnn1bc,Wnn2bc);
    tmax=intervals(idx);
    computeForwardPropagation;
    
    % find optimal lag-point
    meandiff=0;
    t=2;    
    while meandiff <= 0
        meandiff=find(cumsum(PopProbOptimal(1:end,t))>=0.5, 1, 'first')-find(cumsum(PopProbDef(1:end,t))>=0.5, 1, 'first');
        t=t+1;
    end
%    [find(cumsum(PopProbOptimal(1:end,t))>=0.5, 1, 'first') find(cumsum(PopProbDef(1:end,t))>=0.5, 1, 'first')];
    lags(idx)=t;
    
    for i=1:size(PopProbOptimal,2)
        medopt(i)=find(cumsum(PopProbOptimal(1:end,i))>=0.5, 1, 'first');
        meddef(i)=find(cumsum(PopProbDef(1:end,i))>=0.5, 1, 'first');
    end;
end;

fprintf('\n\n');