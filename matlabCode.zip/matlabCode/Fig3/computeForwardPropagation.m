%% Propagate the defensive and the optimal strategy forward
% Defensive phenotype
PopProbDef=zeros(size(skellamPDFdef,1),tmax);
PopProbDef(initPopSZ+1,1)=1;

% propagate probabilities forward
for t=2:tmax
    for k=1:size(skellamPDFdef,2)
        if PopProbDef(k,t-1)>0
            PopProbDef(:,t)=PopProbDef(:,t)+PopProbDef(k,t-1)*skellamPDFdef(:,k);
        end
	end
end
    
% Optimal strategy
PopProbOptimal=zeros(size(skellamPDFdef,1),tmax);
PopProbOptimal(initPopSZ+1,1)=1;

% propagate probabilities forward
for t=2:tmax
    for k=1:size(skellamPDFdef,2)
        if PopProbOptimal(k,t-1)>0
            if Cdiff(t,k+1)<10^-12 % use aggressive strategy?
                PopProbOptimal(:,t)=PopProbOptimal(:,t)+PopProbOptimal(k,t-1)*skellamPDFaggr(:,k);
            else
                PopProbOptimal(:,t)=PopProbOptimal(:,t)+PopProbOptimal(k,t-1)*skellamPDFdef(:,k);
            end
        end
    end
end