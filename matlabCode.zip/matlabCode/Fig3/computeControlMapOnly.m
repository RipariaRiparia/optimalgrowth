function Cdiff=computeControlMapOnly(maxtime,maxsize,Wnn1bc,Wnn2bc)
    initPopSZ=10;
    
    %% Calculate controlmap    
    Jhjb=zeros(maxtime+1,maxsize+1);
    Jhjb(maxtime+1,:)=0:maxsize;                                               % set initial population sizes for backward propagation
    Cdiff=zeros(maxtime,maxsize+1);
    
    v1=zeros(maxsize+1,1);
    v2=zeros(maxsize+1,1);

    for ti=(maxtime+1):-1:2                                                    % a backward recurrence step
        J=Jhjb(ti,:);
        
        for xi=1:(maxsize+1)
            v1(xi)=J(:)'*Wnn1bc(xi,:)'; 
            v2(xi)=J(:)'*Wnn2bc(xi,:)';
        end;   
    
        Jhjb(ti-1,:)=max(v1,v2);
        Cdiff(ti-1,:)=v1-v2;
    end;
end