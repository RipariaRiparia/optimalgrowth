bl=[30 144 255]/255;                                                        % color for the defensive mode
rd=[255 99 71]/255;                                                         % color for the aggressive mode

figure(5);

%% --- plot panel 1E ---
subplot(1,6,1:5);

arr=zeros(749,4);                                                           % compute the population size corresponding P(X<size)=0.5 (=median population size)
for t=2:750    
%    arr(t-1,1)=sum((0:850)'.*PopProbDef(1:end,t));
%    arr(t-1,2)=sum((0:850)'.*PopProbAggr(1:end,t));
%    arr(t-1,3)=sum((0:850)'.*PopProbOptimal(1:end,t));
%    arr(t-1,4)=sum((0:850)'.*PopProbGreedy(1:end,t));
        
    arr(t-1,1)=find(cumsum(PopProbDef(1:end,t))>0.5, 1, 'first')+1;
    arr(t-1,2)=find(cumsum(PopProbAggr(1:end,t))>0.5, 1, 'first')+1;
    arr(t-1,3)=find(cumsum(PopProbOptimal(1:end,t))>0.5, 1, 'first')+1;
    arr(t-1,4)=find(cumsum(PopProbGreedy(1:end,t))>0.5, 1, 'first')+1;
end;

hold on;
plot(arr(:,3),'color',[1 0.70 0],'linewidth',6);                            % plot the first time to get a legend rows into a desired order 
plot(arr(:,4),'k','linewidth',6);
plot(arr(:,2),'color',rd,'linewidth',6);
plot(arr(:,1),'-','color',bl,'linewidth',6);

plot(arr(:,1),'-','color',bl,'linewidth',6);                                % plot the second time to draw curves in a visually pleasing order 
plot(arr(:,2),'color',rd,'linewidth',6);
plot(arr(:,4),'k','linewidth',6);
plot(arr(:,3),'color',[1 0.70 0],'linewidth',6);
plot([1 750],[500 500],'--','color',[0.3 0.3 0.3],'linewidth',3);

xlabel('Time'); 
xlim([1 750]);

ylabel('Median population size');
ylim([0 650]);

set(gca,'fontsize',25,'linewidth',2,'xtick',[40 100 200 300 400 500 600 700]);
box on;
legend('Optimal','Greedy','Aggressive','Defensive');
hold off;
title('panel A');

%% --- plot panel 1F ---
subplot(1,6,6);

hold on;
plot(sum(PopProbDef(2:end,end),2),1:850,'-','color',bl,'linewidth',6);
plot(sum(PopProbAggr(2:end,end),2),1:850,'color',rd,'linewidth',6);         % plot the last time-point densities
plot(sum(PopProbGreedy(2:end,end),2),1:850,'k','linewidth',6);
plot(sum(PopProbOptimal(2:end,end),2),1:850,'color',[1 0.70 0],'linewidth',6);
plot([0 0.1],[500 500],'--','color',[0.3 0.3 0.3],'linewidth',3);

xlim([0 0.023]);
ylim([0 650]);

set(gca,'fontsize',25,'linewidth',2,'yticklabels',[],'xtick',[]);
box on;
title('panel B');