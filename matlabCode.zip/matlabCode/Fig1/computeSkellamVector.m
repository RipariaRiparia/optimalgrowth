function resultVector=computeSkellamVector(kmin,kmax,mu1,mu2)
    maxn=3000;                                                              % the selected boundary for convolution (maximum n)
    
    kn=(-maxn+kmin):(maxn+kmax);                                            % A vector of Poisson probabilities with mu1
    knvec=poisspdf(kn,mu1);
    
    n=-maxn:maxn;                                                           % A vector of Poisson probabilities with mu2
    nvec=poisspdf(n,mu2);

    resultVector=zeros(1,kmax-kmin+1);                                      % allocate space for a result vector
    
    for i=1:(kmax-kmin+1)                                                   % compute Skellam probabilities; do convolution operations
        resultVector(i)=sum(knvec(i:((i-1)+length(n))).*nvec);
    end;
end