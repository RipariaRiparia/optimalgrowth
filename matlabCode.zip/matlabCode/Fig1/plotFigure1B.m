function []=plotFigure1B()
    K = 500;                                                                % carrying capacity
    betaAggr=0.125;                                                         % Birth rate in the aggressive mode
    deltaAggr=0.075;                                                        % Death rate in the aggressive mode
    betaDef=0.025;                                                          % Birth rate in the defensive mode
    deltaDef=0.005;                                                         % Death rate in the defensive mode 
    range=1.75;                                                             % K*range is the maximum population size (empirically set)
    
    %% --- compute transition probabilities ---
    Wnn1=zeros(length(0:(K*range)),length(-40:(K*range)));                  % space for the transition propabilities of the defensive mode                
    Wnn2=zeros(length(0:(K*range)),length(-40:(K*range)));                  % space for the transition probabilities of the aggressive mode

    parfor nInit=0:(K*range)                                                % compute transition matrices
        Wnn1(1+nInit,:)=computeSkellamVector(-40-nInit,(K*range)-nInit,nInit*betaDef,nInit*(deltaDef+(betaDef-deltaDef)*nInit/K));
        Wnn2(1+nInit,:)=computeSkellamVector(-40-nInit,(K*range)-nInit,nInit*betaAggr,nInit*(deltaAggr+(betaAggr-deltaAggr)*nInit/K));
    end;

    negORzero=41;                                                           % merge all probabilities corresponding jumps to negative population sizes to P(sz=0)  

    tmp=[sum(Wnn1(:,1:negORzero),2) Wnn1(:,negORzero+1:end)];
    Wnn1bc=tmp./repmat(sum(tmp,2),1,(K*range)+1);

    tmp=[sum(Wnn2(:,1:negORzero),2) Wnn2(:,negORzero+1:end)]; 
    Wnn2bc=tmp./repmat(sum(tmp,2),1,(K*range)+1);

    
    %% --- compute control map (HJB) --- 
    tmax = 300;                                                             % the last time-point (horizon) 
    maxsize = range*K;                                                      % maximum value for the population size dimension
    
    Jhjb=zeros(tmax+1,maxsize+1);
    Jhjb(tmax+1,:)=0:maxsize;                                               % set initial population sizes for backward propagation
    Cdiff=zeros(tmax,maxsize+1);
    
    v1=zeros(maxsize+1,1);
    v2=zeros(maxsize+1,1);

    for ti=(tmax+1):-1:2                                                    % a backward recurrence step
        J=Jhjb(ti,:);
        
        for xi=1:(range*K+1)
            v1(xi)=J(:)'*Wnn1bc(xi,:)'; 
            v2(xi)=J(:)'*Wnn2bc(xi,:)';
        end;   
    
        Jhjb(ti-1,:)=max(v1,v2);
        Cdiff(ti-1,:)=v1-v2;
    end;

    
    %% --- compute forward simulations ---
    runs=20;
    PopSZ=zeros(runs,tmax);
    
    for j=1:runs
        PopSZ(j,1)=10;                                                      % initial population size is 10
        for t=2:tmax
            n=PopSZ(j,t-1);
            
            if(Cdiff(t,n+1)>0)
                births=poissrnd(n*betaDef);                                 % defensive mode
                deaths=poissrnd(n*(deltaDef+(betaDef-deltaDef)*n/K));                
            else
                births=poissrnd(n*betaAggr);                                % aggressive mode
                deaths=poissrnd(n*(deltaAggr+(betaAggr-deltaAggr)*n/K));                        
            end;
            PopSZ(j,t)=max(0,n+births-deaths);
        end;
    end;     

    
    %% -- plot the control map and three forward simulations ---

    hf=figure(10);                                                           % compute decision boundary between the modes using the contour function
    [C,h]=contour(Cdiff,'-','Color',[0.7 0.7 0.7],'LineWidth',3,'LevelList',[0],'ShowText','off');
    A=h.ContourMatrix;
    close(hf);
    
    figure(2);                                                              % plot a control map
    imagesc(-Cdiff'); hold on;

    setTomatoskyColormap;                                                   % color settings
    caxis([-0.5 0.5]);                                                      

    set(gca,'xtick',[100:100:900]);                                         % x-axis settings
    xlabel('Time','color','k');    
    
    set(gca, 'yDir','normal','yScale','linear');                            % y-axis settings
    ylabel('Population size','color','k');
    ylim([1 600]);
    

    ep=find(A(1,:)==0);                                                     % plot decision boundary 
    plot(A(2,2:end),A(1,2:end),'linewidth',2,'color',(0.5*[30 144 255]+0.5*[255 99 71])/255);
    
    cnt=0;                                                                  % plot three forward simulations
    for i=1:runs
        if PopSZ(i,tmax)>0 & cnt<3                                          % choose simulations that do not go extinct
            u=plot(1:tmax,PopSZ(i,:),'color',[0.4 0.4 0.4],'linewidth',3); u.Color(4) = 0.6;
            u=plot(1:tmax,PopSZ(i,:),'color',[0.65 0.65 0.65],'linewidth',2);            
            cnt=cnt+1;
        end;       
    end;
    plot([1 tmax],[K K],'k--','linewidth',2);                               % plot carrying capacity

    set(gca,'fontsize',40,'linewidth',2);                                   % finetuning the plot
    axis square;
    title('panel B');
    
    hold off;
end
