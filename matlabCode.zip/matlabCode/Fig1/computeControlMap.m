function [Cdiff,Wnn1bc,Wnn2bc]=computeControlMap(tmax)
    K = 500;                                                                % carrying capacity
    betaAggr=0.125;                                                         % Birth rate in the aggressive mode
    deltaAggr=0.075;                                                        % Death rate in the aggressive mode
    betaDef=0.025;                                                          % Birth rate in the defensive mode
    deltaDef=0.005;                                                         % Death rate in the defensive mode
    range=1.75;                                                             % K*range is the maximum population size (empirically set)

    %% --- compute transition probabilities ---
    Wnn1=zeros(length(0:(K*range)),length(-40:(K*range)));                  % space for the transition propabilities of the defensive mode                
    Wnn2=zeros(length(0:(K*range)),length(-40:(K*range)));                  % space for the transition probabilities of the aggressive mode

    parfor nInit=0:(K*range)                                                % compute transition matrices
        Wnn1(1+nInit,:)=computeSkellamVector(-40-nInit,(K*range)-nInit,nInit*betaDef,nInit*(deltaDef+(betaDef-deltaDef)*nInit/K));
        Wnn2(1+nInit,:)=computeSkellamVector(-40-nInit,(K*range)-nInit,nInit*betaAggr,nInit*(deltaAggr+(betaAggr-deltaAggr)*nInit/K));
    end;

    negORzero=41;                                                           % merge all probabilities corresponding jumps to negative population sizes to P(sz=0)  

    tmp=[sum(Wnn1(:,1:negORzero),2) Wnn1(:,negORzero+1:end)];
    Wnn1bc=tmp./repmat(sum(tmp,2),1,(K*range)+1);

    tmp=[sum(Wnn2(:,1:negORzero),2) Wnn2(:,negORzero+1:end)]; 
    Wnn2bc=tmp./repmat(sum(tmp,2),1,(K*range)+1);

    
    %% --- compute control map (HJB) --- 
    maxsize = range*K;                                                      % maximum value for the population size dimension
    
    Jhjb=zeros(tmax+1,maxsize+1);
    Jhjb(tmax+1,:)=0:maxsize;                                               % set initial population sizes for backward propagation
    Cdiff=zeros(tmax,maxsize+1);
    
    v1=zeros(maxsize+1,1);
    v2=zeros(maxsize+1,1);

    for ti=(tmax+1):-1:2                                                    % a backward recurrence loop
        J=Jhjb(ti,:);
        
        for xi=1:(range*K+1)
            v1(xi)=J(:)'*Wnn1bc(xi,:)'; 
            v2(xi)=J(:)'*Wnn2bc(xi,:)';
        end;   
    
        Jhjb(ti-1,:)=max(v1,v2);
        Cdiff(ti-1,:)=v1-v2;
    end; 
end
