skellamPDFdef=Wnn1bc(1:651,1:851)';
skellamPDFaggr=Wnn2bc(1:651,1:851)';

initPopSZ=10;
K=500;

%% defensive phenotype
PopProbDef=zeros(size(skellamPDFdef,1),tmax);
PopProbDef(initPopSZ+1,1)=1;

% propagate probabilities forward
for t=2:tmax
    for k=1:size(skellamPDFdef,2)
        if PopProbDef(k,t-1)>0
            PopProbDef(:,t)=PopProbDef(:,t)+PopProbDef(k,t-1)*skellamPDFdef(:,k);
        end;
    end;
end;

%% aggressive phenotype
PopProbAggr=zeros(size(skellamPDFaggr,1),tmax);
PopProbAggr(initPopSZ+1,1)=1;

% propagate probabilities forward
for t=2:tmax
    for k=1:size(skellamPDFaggr,2)
        if PopProbAggr(k,t-1)>0
            PopProbAggr(:,t)=PopProbAggr(:,t)+PopProbAggr(k,t-1)*skellamPDFaggr(:,k);
        end;
    end;
end;

%% greedy phenotype
PopProbGreedy=zeros(size(skellamPDFaggr,1),tmax);
PopProbGreedy(initPopSZ+1,1)=1;

% propagate probabilities forward
for t=2:tmax
    for k=1:size(skellamPDFaggr,2)
        if PopProbGreedy(k,t-1)>0
            if Cdiff(end,k+1)<0                                             % which strategy?
                PopProbGreedy(:,t)=PopProbGreedy(:,t)+PopProbGreedy(k,t-1)*skellamPDFaggr(:,k);
            else
                PopProbGreedy(:,t)=PopProbGreedy(:,t)+PopProbGreedy(k,t-1)*skellamPDFdef(:,k);
            end;
        end;
    end;
end;

%% optimal
PopProbOptimal=zeros(size(skellamPDFaggr,1),tmax);
PopProbOptimal(initPopSZ+1,1)=1;

% propagate probabilities forward
for t=2:tmax
    for k=1:size(skellamPDFaggr,2)
        if PopProbOptimal(k,t-1)>0
            if Cdiff(t,k+1)<0                                               % which strategy?
                PopProbOptimal(:,t)=PopProbOptimal(:,t)+PopProbOptimal(k,t-1)*skellamPDFaggr(:,k);
            else
                PopProbOptimal(:,t)=PopProbOptimal(:,t)+PopProbOptimal(k,t-1)*skellamPDFdef(:,k);
            end;
        end;
    end;
end;
