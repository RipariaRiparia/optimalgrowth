% writes animation of forward propagation of distributions over time
figure(4);

v = VideoWriter('tmp.mp4','MPEG-4');
v.Quality = 95;
v.FrameRate=20;
open(v);
for t=2:2:750                                                               % loop over time
    plot(sum(PopProbDef(2:end,t),2),'color',[0.1176 0.5647 1.0000],'linewidth',4); hold on;
    plot(sum(PopProbAggr(2:end,t),2),'color',[1.0000 0.3882 0.2784],'linewidth',4); 
    plot(sum(PopProbGreedy(2:end,t),2),'k','linewidth',4); 
    plot(sum(PopProbOptimal(2:end,t),2),'color',[1 0.7 0],'linewidth',4); 
    plot([500 500],[-0.001 0.023],'--','color',[0.4 0.4 0.4],'linewidth',3);
    hold off;
    
    ylim([-0.0002 0.023]);
    xlim([1 700]);
    title(sprintf('time = %d / 750',t));
    set(gca,'ytick',[]);
    xlabel('Population size');
    ylabel('Probability');
    set(gca,'linewidth',2,'fontsize',25);
    
    if t==2
        legend('Defensive','Aggressive','Greedy','Optimal');
    end;
    
    [img, Map] = frame2im(getframe(gcf));    
    writeVideo(v,img);    

    pause(0.005);
end;
close(v);