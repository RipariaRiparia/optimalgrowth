fprintf('\nFigure 1:\n  Computing panel A ...\n');
plotFigure1A; 
pause(0.1);                                                                 % pausing 0.1s between panels to give enough time for drawing

fprintf('  Computing panel B ...\n');
plotFigure1B; 
pause(0.1);

fprintf('  Computing panel C ...\n');
plotFigure1C; 
pause(0.1);

fprintf('  Computing a simulation ...\n');              
[Cdiff,Wnn1bc,Wnn2bc]=computeControlMap(750);
tmax=750; PropagateProbabilities;
populationGrowthAnimation;
