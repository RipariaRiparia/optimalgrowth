%% plot the controlcube
K = 500;                                                                
tmax=500;

%% plot the via time slices
figure(1)
subplot(1,2,1)
timestep=1; % first step is 1
imagesc(-squeeze(CtrlCube(timestep,2:end,2:end))) % exclude zero pops -> colormap sets 0 to aggressive
hold on
caxis([-1 1]); 
setTomatoskyColormap;
set(gca,'ydir','normal','linewidth',3,'fontsize',20); 
xlabel('Own population size')
ylabel('Competitor size')
title(['Timestep ',num2str(timestep)])
plot(K:-1:1,'--','linewidth',3)
axis square;
xlim([0 550]);
ylim([0 550]);

subplot(1,2,2)
timestep=500; %tmax; % first step is 1
imagesc(-squeeze(CtrlCube(timestep,2:end,2:end))) % exclude zero pops -> colormap sets 0 to aggressive
hold on
caxis([-1 1]); 
setTomatoskyColormap;
set(gca,'ydir','normal','linewidth',3,'fontsize',20); 
xlabel('Own population size')
ylabel('Competitor size')
title(['Timestep ',num2str(timestep)])
plot(K:-1:1,'--','linewidth',3)
axis square;
xlim([0 550]);
ylim([0 550]);