load('../Fig5/optCube');                % A binary cube unlike in the manuscript (K=500)
plotFigS1;