%% compute and set color map

bl=[30 144 255]/255;                                                        % sky blue color
rd=[255 99 71]/255;                                                         % tomato red color

mx=1:-0.01:0;                                                               % lattices
mxflip=0:0.01:1;
sz=length(mx);

PartA=ones(sz,3).*[mxflip' mxflip' mxflip']+[mx' mx' mx'].*repmat(bl,sz,1); % a blue color slide from blue to white
PartB=ones(sz,3).*[mx' mx' mx']+[mxflip' mxflip' mxflip'].*repmat(rd,sz,1); % a red color slide from white to red

map=[PartA;PartB];                                                          % merge two slides
map(76:127,:)=[];                                                           % remove the white part 

colormap(map);                                                              % set the colormap

