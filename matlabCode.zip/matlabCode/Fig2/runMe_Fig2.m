fprintf('  Computing a Skellam transition matrix ...\n');

cd ../Fig1;
[Cdiff,Wnn1bc,Wnn2bc]=computeControlMap(600);
tmax=600; PropagateProbabilities;
cd ../Fig2;

fprintf('  Computing panel A ...\n');
plotFigure2A;
pause(0.1);

fprintf('  Computing panel B ...\n');
plotFigure2B;
pause(0.1);