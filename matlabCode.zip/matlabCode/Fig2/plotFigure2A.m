tmax=200;
init=500;
K=500;
bndry=530;

% Propagating probabilities of aggressive phenotype
PopProbAgressive=zeros(size(skellamPDFaggr,1),tmax);
PopProbAgressive(init+1,1)=1;

for t=2:tmax
    for k=1:size(skellamPDFaggr,2)            
        PopProbAgressive(:,t)=PopProbAgressive(:,t)+PopProbAgressive(k,t-1)*skellamPDFaggr(:,k);
    end;
end;

% Propagating probabilities of optimal phenotype
PopProbOptimal=zeros(size(skellamPDFaggr,1),tmax);
PopProbOptimal(init+1,1)=1;

for t=2:tmax
    for k=1:size(skellamPDFaggr,2)
        if PopProbOptimal(k,t-1)>0
            if k+1<(bndry+1)
                PopProbOptimal(:,t)=PopProbOptimal(:,t)+PopProbOptimal(k,t-1)*skellamPDFaggr(:,k);
            else
                PopProbOptimal(:,t)=PopProbOptimal(:,t)+PopProbOptimal(k,t-1)*skellamPDFdef(:,k);
            end;
        end;
    end;
end;

%% plotting
col1=[0.1176 0.5647 1.0000]; 
col2=[1.0000 0.3882 0.2784];

figure(2);
rectangle('Position',[0 0 bndry 800],'FaceColor',col2,'EdgeColor',col2); hold on;
rectangle('Position',[bndry 0 700-bndry 800],'FaceColor',col1,'EdgeColor',col1); 
bar((5:10:845)-1,mean(reshape(PopProbOptimal(1:850,end),10,85),1),'facecolor',[0.85 0.85 0.85],'linewidth',1);
plot([500 500],[0 800],'--k','linewidth',3);
plot(0:(size(PopProbAgressive,1)-1),PopProbAgressive(:,end),'-.k','linewidth',2);

set(gca,'ytick',[]);
axis square;
set(gca, 'fontsize',25,'linewidth',2);
xlabel('Population size','fontsize',30);
xlim([145 700]);
ylim([0 0.016]);
box on;
ax=findall(gcf,'type','axes');
ax.Layer='top';
hold off;
title('A. Maximizing boundary');