function CtrlCube=computeOptCube()
    % Optimal competitor

    % carrying capacity and computation area
    K = 500;                                                                
    range=1.75;
    tmax=500;

    % optimal strategy (input: own density, competitor density, time)
    controlCube=zeros(range*K+1,range*K+1,tmax);

    % initialize cost-to-go
    Jhjb=zeros(range*K+1,range*K+1,tmax+1);
    Jhjb(:,:,tmax+1)=repmat(0:(K*range),K*range+1,1)'; % boundary condition: only the final own density matters 

    % birth and death rates for the strategies
    betaAgr=0.125;
    deltaAgr=0.075; 
    betaDef=0.025;
    deltaDef=0.005;

    %%
    Wnn1bcM=zeros(range*K+1,range*K+1,range*K+1);
    Wnn2bcM=zeros(range*K+1,range*K+1,range*K+1);

    for yi=0:(range*K)
        for xi=0:(range*K)
            % calculate transition probabilities
            Wnn1=computeSkellamVector(-60-xi,(K*range)-xi,xi*betaDef,xi*(deltaDef+(betaDef-deltaDef)*(xi+yi)/K));
            Wnn2=computeSkellamVector(-60-xi,(K*range)-xi,xi*betaAgr,xi*(deltaAgr+(betaAgr-deltaAgr)*(xi+yi)/K));
            
            % normalize
            neqORzero=61;
            tmp=[sum(Wnn1(:,1:neqORzero),2) Wnn1(:,neqORzero+1:end)];
            Wnn1bcM(xi+1,yi+1,:)=gpuArray(tmp./repmat(sum(tmp,2),1,(K*range)+1));

            tmp=[sum(Wnn2(:,1:neqORzero),2) Wnn2(:,neqORzero+1:end)]; 
            Wnn2bcM(xi+1,yi+1,:)=gpuArray(tmp./repmat(sum(tmp,2),1,(K*range)+1));  
        end
    end
    
    WnncbcDef=gpuArray(permute(Wnn1bcM,[2 1 3]));
    WnncbcAgr=gpuArray(permute(Wnn2bcM,[2 1 3]));      
    
    % backward propagation (HJB)
    for ti=(tmax+1):-1:2 % loop backwards in time from boundary condition
        J=gpuArray(Jhjb(:,:,ti));
        Jnew=Jhjb(:,:,ti-1);
        Cnew=controlCube(:,:,ti-1); 
        V1=zeros(1,range*K+1);
        V2=zeros(1,range*K+1);
        
        for yi=0:(range*K) % loop over all competitor sizes            
            selectionVec=(0:(range*K))+yi >= K;                               
            
            Wnncbc=gpuArray(repmat(selectionVec',1,K*range+1).*squeeze(WnncbcDef(:,yi+1,:))+not(repmat(selectionVec',1,K*range+1)).*squeeze(WnncbcAgr(:,yi+1,:)));
            Wnn1bc=gpuArray(squeeze(Wnn1bcM(:,yi+1,:)));
            Wnn2bc=gpuArray(squeeze(Wnn2bcM(:,yi+1,:)));

            % save gains
            V1=sum(J'*Wnn1bc'.*Wnncbc');
            V2=sum(J'*Wnn2bc'.*Wnncbc');                     
            
            Jnew(:,yi+1)=max(V1,V2);
            Cnew(:,yi+1)=V1-V2;
        end
 
        Jhjb(:,:,ti-1)=Jnew;
        controlCube(:,:,ti-1)=Cnew;
    end
    
    CtrlCube=permute(controlCube,[3 1 2]);
    CtrlCube=(CtrlCube>=0);
end
