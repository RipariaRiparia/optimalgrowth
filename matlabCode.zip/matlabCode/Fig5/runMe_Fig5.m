runs=100;                                                                    % simulations per cycle length: in the paper 20000
load('AnticipCube.mat');                                                     % Previously saved CtrlCube (anticipative competitor)

fprintf('(These computations are really slow with 20000 runs (many hours each)\n');
fprintf('\nFigure 5:\n  Computing panel A ...\n  Cycle length: ');
computeFigure5A;
stackedBarPlotDefensiveAnticip;
pause(0.5);

fprintf('  Computing panel B ...\n  Cycle length: ');
computeFigure5B;
stackedBarPlotAggressiveAnticip;
pause(0.5);

fprintf('  Computing panel C ...\n  Cycle length: ');
computeFigure5C;
stackedBarPlotGreedyAnticip;
pause(0.5);

fprintf('  Computing panel D ...\n  Cycle length: ');

load('OptCube');                                                             % either load a previously saved optimal control cube (binary)
%CtrlCube=computeOptCube();                                                  % or compute the cube (needs Nvidia GPU)
computeFigure5D;
stackedBarPlotGreedyOpt;