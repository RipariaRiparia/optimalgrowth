col1=[30 144 255]/255;
col2=[0.7 0.7 0.7];
col3=[255 99 71]/255; 
col4=[1 0.70 0];
col5=[0 0 0];

cyclelens=600:-25:25;

xx=[(runs-(HistogramStorage(:,3)+counts(:,1)))/runs counts(:,2:21)/runs (runs-(HistogramStorage(:,2)+counts(:,22)))/runs];
data=[xx(:,22) sum(xx(:,2:21),2) xx(:,1)];

figure(1); 
H=bar(cyclelens,data,'stacked','FaceColor','flat');
ylim([0 1]);
xlim([10 515]);
set(gca,'linewidth',1.5,'ytick',[],'fontsize',25);
xlabel('Cycle length');
ylabel('Win fraction');

H(1).CData=repmat(col4,24,1);
H(2).CData=repmat(col2,24,1);
H(3).CData=repmat(col1,24,1);
title('Defensive vs.       Anticipative','fontsize',30);
axis square;

hold on;
plot([0 550],[0.5 0.5],'--','linewidth',3,'color',[0.4 0.4 0.4]);
hold off;

