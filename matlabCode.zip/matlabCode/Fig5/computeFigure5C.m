%runs=250;
K=500; 
proportion=0.1;

betaAggr=0.125;                                                         % Birth rate in the aggressive mode
deltaAggr=0.075;                                                        % Death rate in the aggressive mode
betaDef=0.025;                                                          % Birth rate in the defensive mode
deltaDef=0.005;                                                         % Death rate in the defensive mode  

cycles=6;                                                                   % the number of cycles in a competition 
timesteps=600;

HistogramStorage=-ones(24,3+runs);

for timeLengthIdx=1:24                                                      % over different time windows
    cropPart=(timeLengthIdx-1)*25;                                          
    PopSZ=zeros(runs,(timesteps-cropPart)*cycles,2);
    
    parfor j=1:runs                                                         % over the number of runs
        PopSZtmp=zeros((timesteps-cropPart)*cycles,2);        
        n1Initial=K/2*proportion;
        n2Initial=K/2*proportion;
    
        for k=1:cycles                                                      % over the number of competition cycles
            shft=(k-1)*(timesteps-cropPart);
            PopSZtmp(shft+1,1)=n1Initial;
            PopSZtmp(shft+1,2)=n2Initial;
        
            for t=2:(timesteps-cropPart)
                n1=PopSZtmp(shft+t-1,1);
                n2=PopSZtmp(shft+t-1,2);
                
                % greedy phenotype
                if(CtrlCube(600,n1+1,n2+1)>0)
                    births1=poissrnd(n1*betaDef);
                    deaths1=poissrnd(n1*(deltaDef+(betaDef-deltaDef)*(n1+n2)/K));                
                else
                    births1=poissrnd(n1*betaAggr);
                    deaths1=poissrnd(n1*(deltaAggr+(betaAggr-deltaAggr)*(n1+n2)/K));                        
                end;   

                % optimal phenotype
                if(CtrlCube(cropPart+t,n2+1,n1+1)>0)
                    births2=poissrnd(n2*betaDef);
                    deaths2=poissrnd(n2*(deltaDef+(betaDef-deltaDef)*(n1+n2)/K));                
                else
                    births2=poissrnd(n2*betaAggr);
                    deaths2=poissrnd(n2*(deltaAggr+(betaAggr-deltaAggr)*(n1+n2)/K));                        
                end;

                PopSZtmp(shft+t,1)=max(0,n1+births1-deaths1);
                PopSZtmp(shft+t,2)=max(0,n2+births2-deaths2);                                                
            end;
        
            if (PopSZtmp(shft+(timesteps-cropPart),1)+PopSZtmp(shft+(timesteps-cropPart),2))==0
                n1Initial=0;
                n2Initial=0;
            else
                n1Initial=round((K*proportion)*PopSZtmp(shft+(timesteps-cropPart),1)/(PopSZtmp(shft+(timesteps-cropPart),1)+PopSZtmp(shft+(timesteps-cropPart),2)));
                n2Initial=round((K*proportion)*PopSZtmp(shft+(timesteps-cropPart),2)/(PopSZtmp(shft+(timesteps-cropPart),1)+PopSZtmp(shft+(timesteps-cropPart),2)));
            end;
        end;
        
        PopSZ(j,:,:)=PopSZtmp;
    end;
    
    filt1=(PopSZ(:,end,1)>0);                                               % find those that persist to the end
    filt2=(PopSZ(:,end,2)>0);    
    
    HistogramStorage(timeLengthIdx,1:3)=[timesteps-cropPart sum(filt1) sum(filt2)]; % save interval length, #survivors of phenotype1, #survivors of phenotype2
    for g=1:runs
        if (filt1(g) & filt2(g))                                            % when both survive, save a corresponding histogram value 
            HistogramStorage(timeLengthIdx,3+g)=PopSZ(g,end,2)/(PopSZ(g,end,1)+PopSZ(g,end,2));
        end;
    end;    
    
    fprintf('%d ',timesteps-cropPart);
    clear PopSZ;
end;
fprintf('\n');

%% --- plot panel A ---
%figure(3);

counts=zeros(24,22);                                                        % compute histograms
for hc=1:24 
    counts(hc,:)=histcounts(HistogramStorage(hc,4:end),-0.05:0.05:1.05); 
end;

% plot non-persisting populations to left and right and the computed histogram in the middle
%imagesc([(runs-(HistogramStorage(:,3)+counts(:,1)))/runs counts(:,2:21)/runs (runs-(HistogramStorage(:,2)+counts(:,22)))/runs]); 
%colormap(jet(48))
%caxis([0 0.5]);
%colorbar;

%hold on;                                                                    % plot horizontal lines between different cycle lengths
%for i=1:23 
%    plot([0.5 23.5],i+[0.5 0.5],'k'); 
%end;
%hold off;

%set(gca,'linewidth',2,'fontsize',25);
%set(gca,'xtick',[1 6 10 14 18 22],'xticklabels',[0 0.2 0.4 0.6 0.8 1]);
%set(gca,'ytick',[1 5 9 13 17 21 24],'yticklabels',[600 500 400 300 200 100 25]);
%ax=gca;
%ax.TickLength=[0, 0];

%ylabel('Cycle length');
%title('Greedy                          Optimal');

