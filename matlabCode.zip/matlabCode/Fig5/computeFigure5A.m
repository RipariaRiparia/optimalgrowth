K=500; 
proportion=0.1;

betaAggr=0.125;                                                         % Birth rate in the aggressive mode
deltaAggr=0.075;                                                        % Death rate in the aggressive mode
betaDef=0.025;                                                          % Birth rate in the defensive mode
deltaDef=0.005;                                                         % Death rate in the defensive mode 

cycles=6;                                                                   % the number of cycles in a competition 
timesteps=600;

HistogramStorage=-ones(24,3+runs);

for timeLengthIdx=1:24                                                      % over different time windows
    cropPart=(timeLengthIdx-1)*25;                                          
    PopSZ=zeros(runs,(timesteps-cropPart)*cycles,2);
    
    parfor j=1:runs                                                         % over the number of runs
        PopSZtmp=zeros((timesteps-cropPart)*cycles,2);        
        n1Initial=K/2*proportion;
        n2Initial=K/2*proportion;
    
        for k=1:cycles                                                      % over the number of competition cycles
            shft=(k-1)*(timesteps-cropPart);
            PopSZtmp(shft+1,1)=n1Initial;
            PopSZtmp(shft+1,2)=n2Initial;
        
            for t=2:(timesteps-cropPart)
                n1=PopSZtmp(shft+t-1,1);
                n2=PopSZtmp(shft+t-1,2);
                
                % defensive phenotype
                birthsPop1=poissrnd(n1*betaDef);
                deathsPop1=poissrnd(n1*(deltaDef+(betaDef-deltaDef)*(n1+n2)/K)); 

                % optimal phenotype
                if(CtrlCube(cropPart+t,n2+1,n1+1)>0)
                    birthsPop2=poissrnd(n2*betaDef);
                    deathsPop2=poissrnd(n2*(deltaDef+(betaDef-deltaDef)*(n1+n2)/K));                
                else
                    birthsPop2=poissrnd(n2*betaAggr);
                    deathsPop2=poissrnd(n2*(deltaAggr+(betaAggr-deltaAggr)*(n1+n2)/K));                        
                end;

                PopSZtmp(shft+t,1)=max(0,n1+birthsPop1-deathsPop1);
                PopSZtmp(shft+t,2)=max(0,n2+birthsPop2-deathsPop2);                                                
            end;
        
            if (PopSZtmp(shft+(timesteps-cropPart),1)+PopSZtmp(shft+(timesteps-cropPart),2))==0
                n1Initial=0;
                n2Initial=0;
            else
                n1Initial=round((K*proportion)*PopSZtmp(shft+(timesteps-cropPart),1)/(PopSZtmp(shft+(timesteps-cropPart),1)+PopSZtmp(shft+(timesteps-cropPart),2)));
                n2Initial=round((K*proportion)*PopSZtmp(shft+(timesteps-cropPart),2)/(PopSZtmp(shft+(timesteps-cropPart),1)+PopSZtmp(shft+(timesteps-cropPart),2)));
            end;
        end;
        
        PopSZ(j,:,:)=PopSZtmp;
    end;
    
    filt1=(PopSZ(:,end,1)>0);                                               % find those that persist to the end
    filt2=(PopSZ(:,end,2)>0);    
    
    HistogramStorage(timeLengthIdx,1:3)=[timesteps-cropPart sum(filt1) sum(filt2)]; % save interval length, #survivors of phenotype1, #survivors of phenotype2
    for g=1:runs
        if (filt1(g) & filt2(g))                                            % when both survive, save a corresponding histogram value 
            HistogramStorage(timeLengthIdx,3+g)=PopSZ(g,end,2)/(PopSZ(g,end,1)+PopSZ(g,end,2));
        end;
    end;    
    
    fprintf('%d ',timesteps-cropPart);
    clear PopSZ;
end;
fprintf('\n');

%% --- histograms for plotting panel A ---

counts=zeros(24,22);                                                       
for hc=1:24 
    counts(hc,:)=histcounts(HistogramStorage(hc,4:end),-0.05:0.05:1.05); 
end;
